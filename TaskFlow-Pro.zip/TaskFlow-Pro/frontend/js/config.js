// Configuration will be updated after Cognito setup
const config = {
    cognito: {
        domain: '', // Will be filled after Cognito setup
        clientId: '', // Will be filled after Cognito setup
        redirectUri: '', // Will be S3 website URL
        region: 'us-east-1'
    },
    api: {
        endpoint: '' // Will be filled after API Gateway setup
    }
};